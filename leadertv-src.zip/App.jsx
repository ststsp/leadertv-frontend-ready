import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import News from './components/News';
import EventsCalendar from './components/EventsCalendar';
import NewsPage from './pages/NewsPage';
import EventsPage from './pages/EventsPage';
import './index.css';

export default function App() {
  return (
    <Router>
      <header>
        <nav>
          <Link to="/">Начало</Link>
          <Link to="/news">Новини</Link>
          <Link to="/events">Събития</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<>
            <h2>Новини</h2>
            <News />
            <h2>Календар на събития</h2>
            <EventsCalendar />
          </>} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/events" element={<EventsPage />} />
        </Routes>
      </main>
      <footer>
        &copy; {new Date().getFullYear()} LeaderTV. Всички права запазени.
      </footer>
    </Router>
  );
}
