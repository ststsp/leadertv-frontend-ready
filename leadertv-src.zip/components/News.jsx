import { useEffect, useState } from 'react';

export default function News() {
  const [news, setNews] = useState([]);
  useEffect(() => {
    fetch(import.meta.env.VITE_API_URL + '/api/news')
      .then(res => res.json())
      .then(data => setNews(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      {news.map((n, i) => (
        <div key={i}>
          <h3>{n.title}</h3>
          <p>{n.description}</p>
        </div>
      ))}
    </div>
  );
}
