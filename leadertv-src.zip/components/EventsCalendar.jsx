import { useEffect, useState } from 'react';

export default function EventsCalendar() {
  const [events, setEvents] = useState([]);
  useEffect(() => {
    fetch(import.meta.env.VITE_API_URL + '/api/events')
      .then(res => res.json())
      .then(data => setEvents(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      {events.map((e, i) => (
        <div key={i}>
          <h3>{e.title}</h3>
          <p>{e.location} — {new Date(e.date).toLocaleString()}</p>
        </div>
      ))}
    </div>
  );
}
