import News from '../components/News';
export default function NewsPage() {
  return <div><h1>Всички новини</h1><News /></div>;
}
