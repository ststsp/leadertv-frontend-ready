import EventsCalendar from '../components/EventsCalendar';
export default function EventsPage() {
  return <div><h1>Всички събития</h1><EventsCalendar /></div>;
}
